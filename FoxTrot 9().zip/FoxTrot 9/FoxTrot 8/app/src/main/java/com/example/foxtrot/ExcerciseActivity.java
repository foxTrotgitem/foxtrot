package com.example.foxtrot;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ExcerciseActivity extends AppCompatActivity{
    //hi all, tod here, I AM GOING TO CRY
    private static final int ADD_EXERCISE_REQUEST=1;
    private List<Exercise> exercises=new ArrayList<>();
    private LinearLayout layout;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.main_activity_scrollview);
        layout=findViewById(R.id.exercises_linear_layout);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) ->{
            Insets systemBars=insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        }); //I have no idea
        loadExercises();
        Button exercise1Button=findViewById(R.id.exercise_1);
        exercise1Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(ExcerciseActivity.this, StartWorkoutActivity.class);
                intent.putExtra("TIMER_DURATION", 15 * 60 * 1000L);
                startActivity(intent);
            }
        });
        Button exercise2Button=findViewById(R.id.exercise_2);
        exercise2Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(ExcerciseActivity.this, StartWorkoutActivity.class);
                intent.putExtra("TIMER_DURATION", 30 * 60 * 1000L);
                startActivity(intent);
            } //UBACHAAARGE
        });
        ImageButton addNewExerciseButton=findViewById(R.id.add_exercise);
        addNewExerciseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(ExcerciseActivity.this, AddExerciseActivity.class);
                startActivityForResult(intent, ADD_EXERCISE_REQUEST);
            }
        });
        ImageView getDataButton=findViewById(R.id.getdata);
        getDataButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(ExcerciseActivity.this, StartWorkoutActivity.class);
                intent.putExtra("TIMER_DURATION", 10 * 60 * 1000L); // 10 minutes default
                startActivity(intent);
            }
        });
        ImageButton sendToShop=findViewById(R.id.sendtoshop);
        sendToShop.setOnClickListener(v ->{
            Intent intent=new Intent(ExcerciseActivity.this, Shop.class);
            startActivity(intent);
        });
        ImageButton sendToWorkout=findViewById(R.id.sendtoworkout);
        sendToWorkout.setOnClickListener(v ->{
            Intent intent=new Intent(ExcerciseActivity.this, ExcerciseActivity.class);
            startActivity(intent);
        });
        ImageButton sendToSettings=findViewById(R.id.sendtosetting);
        sendToSettings.setOnClickListener(v ->{
            Intent intent=new Intent(ExcerciseActivity.this, SettingsActivity.class);
            startActivity(intent);
        });
        ImageButton sendToMainPage=findViewById(R.id.sendtomainpage);
        sendToMainPage.setOnClickListener(v ->{
            Intent intent=new Intent(ExcerciseActivity.this, Screentwo.class);
            startActivity(intent);
        });
        ImageButton sendToInventory=findViewById(R.id.sendtoinventory);
        sendToInventory.setOnClickListener(v ->{
            Intent intent=new Intent(ExcerciseActivity.this, Inventory.class);
            startActivity(intent);
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==ADD_EXERCISE_REQUEST && resultCode==RESULT_OK){
            String exerciseName=data.getStringExtra("exercise_name");
            long exerciseTime=data.getIntExtra("exercise_time", 0) * 60 * 1000L;
            Exercise newExercise=new Exercise(exerciseName, exerciseTime);
            exercises.add(newExercise);
            addExerciseButton(newExercise);
            saveExercises();
        } //WHART DOES RTHIS DO
    }
    private void saveExercises(){
        SharedPreferences sharedPreferences=getSharedPreferences("exercises", MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        Gson gson=new Gson();
        String json=gson.toJson(exercises);
        editor.putString("exercise_list", json);
        editor.apply();
    }
    private void loadExercises(){
        SharedPreferences sharedPreferences=getSharedPreferences("exercises", MODE_PRIVATE);
        Gson gson=new Gson();
        String json=sharedPreferences.getString("exercise_list", null);
        Type type=new TypeToken<ArrayList<Exercise>>(){}.getType();
        exercises=gson.fromJson(json, type);
        if (exercises == null){
            exercises=new ArrayList<>();
        }
        for (Exercise exercise : exercises){
            addExerciseButton(exercise);
        }
    }
    private void addExerciseButton(Exercise exercise){
        Button newExerciseButton=new Button(this);
        newExerciseButton.setText(exercise.getName());
        int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 59, getResources().getDisplayMetrics());
        int width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 189, getResources().getDisplayMetrics());
        int marginBottom = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 16, getResources().getDisplayMetrics());

        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(width, height);
        params.setMargins(0, 0, 0, marginBottom);
        newExerciseButton.setLayoutParams(params);
        newExerciseButton.setBackgroundResource(R.drawable.button_corners);
        newExerciseButton.setTextColor(ContextCompat.getColor(this, android.R.color.black));
        newExerciseButton.setTextSize(18);
        newExerciseButton.setOnClickListener(v ->{
            Intent intent=new Intent(ExcerciseActivity.this, StartWorkoutActivity.class);
            intent.putExtra("TIMER_DURATION", exercise.getTime());
            startActivity(intent);
        });
        layout.addView(newExerciseButton);
    }
    static class Exercise{
        private String name;
        private long time;
        public Exercise(String name, long time){
            this.name=name;
            this.time=time;
        }
        public String getName(){
            return name;
        }
        //help
        public long getTime(){
            return time;
        }
    }
}
