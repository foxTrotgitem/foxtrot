package com.example.foxtrot;


import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


@Entity(tableName = "userInfo")
public class UserInfo {
    @PrimaryKey(autoGenerate = true)
    @NonNull public int uid;
    @ColumnInfo (name = "last_name")
    public String theEmail;
    public String first_name;
    public String thePassword;
    public boolean skipLogin=false;

    public UserInfo(String email, String fname, String password, boolean skip){
        theEmail = email;
        first_name = fname;
        thePassword = password;
        skipLogin=skip;
    }
    public UserInfo() {}
}
