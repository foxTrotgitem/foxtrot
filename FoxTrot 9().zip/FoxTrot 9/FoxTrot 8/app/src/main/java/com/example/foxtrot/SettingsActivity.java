package com.example.foxtrot;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Switch;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;
//sun tzu said that (tod)
public class SettingsActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        //go my bricks
        setContentView(R.layout.activity_settings);
        SharedPreferences sharedPreferences=getSharedPreferences("settings", MODE_PRIVATE);
        boolean isDarkMode=sharedPreferences.getBoolean("dark_mode", false);
        if(isDarkMode){
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.system_bars_dark));
        }
        else{
            getWindow().setStatusBarColor(ContextCompat.getColor(this, android.R.color.white));
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main),(v, insets) ->{
            Insets systemBars=insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Switch darkModeSwitch=findViewById(R.id.darkModeSwitch);
        darkModeSwitch.setChecked(isDarkMode);
        darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->{
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putBoolean("dark_mode", isChecked);
            editor.apply();
            if(isChecked){
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            }
            else{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
        });
        Button languageButton=findViewById(R.id.language);
        languageButton.setOnClickListener(v ->{
            final String[] languages={"English", "Spanish", "Chinese", "French"};
            AlertDialog.Builder builder=new AlertDialog.Builder(SettingsActivity.this);
            builder.setTitle("Select Language!");
            //Language time, spam tab and pray!
            builder.setItems(languages, new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int which){
                    switch(which){
                        //schrodingers  switch case
                        case 0:
                            setLocale("en");
                            break;
                        case 1:
                            setLocale("es");
                            break;
                        case 2:
                            setLocale("zh");
                            break;
                        case 3:
                            setLocale("fr");
                            break;
                    }
                } //press tab and pray press tab and pray press tab and pray press tab and pray
            });
            builder.show();
        });
        Button helpCenterButton=findViewById(R.id.HelpCenter);
        helpCenterButton.setOnClickListener(v ->{
            Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.parsemus.org/project/alzheimers-disease-prevention/?gad_source=1&gad_campaignid=23002342557&gbraid=0AAAAABeo_rZe1vaMCRa6vCJqjjFJrYR0p&gclid=CjwKCAiA8vXIBhAtEiwAf3B-g5XOkr8Y0DpWJGCls74VgtYUo5t7GIphQVWwf0Su3DthhDc5uJXVxhoCU48QAvD_BwE"));
            startActivity(intent);
        });
        ImageButton sendToShop=findViewById(R.id.sendtoshop);
        sendToShop.setOnClickListener(v ->{
            Intent intent=new Intent(SettingsActivity.this, Shop.class);
            startActivity(intent);
        });
        ImageButton sendToWorkout=findViewById(R.id.sendtoworkout);
        sendToWorkout.setOnClickListener(v ->{
            Intent intent=new Intent(SettingsActivity.this, ExcerciseActivity.class);
            startActivity(intent);
        });
        ImageButton sendToSettings=findViewById(R.id.sendtosetting);
        sendToSettings.setOnClickListener(v ->{
            Intent intent=new Intent(SettingsActivity.this, SettingsActivity.class);
            startActivity(intent);
        });
        ImageButton sendToMainPage=findViewById(R.id.sendtomainpage);
        sendToMainPage.setOnClickListener(v ->{
            Intent intent=new Intent(SettingsActivity.this, Screentwo.class);
            startActivity(intent);
        });
        ImageButton sendToInventory=findViewById(R.id.sendtoinventory);
        sendToInventory.setOnClickListener(v ->{
            Intent intent=new Intent(SettingsActivity.this, Inventory.class);
            startActivity(intent);
        });
    }//somehow it worked!
    private void setLocale(String lang){
        Locale locale=new Locale(lang);
        Locale.setDefault(locale);
        Resources resources=getResources();
        Configuration config=resources.getConfiguration();
        config.setLocale(locale);
        resources.updateConfiguration(config, resources.getDisplayMetrics());
        recreate();
    }
}