package com.example.foxtrot;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.annotation.DrawableRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.foxtrot.Acorns;

import java.util.ArrayList;

public class Inventory extends AppCompatActivity {

    private boolean equippedhat = false;
    private boolean equippedshirt = false;

    private ArrayList<String> items_in_inventory_for_display = new ArrayList<>();


    @Override
    //Simba everything you see here was made by Zachary "About to die of exhaustion" Pressler. May his soul find eternal rest in the after life
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        LinearLayout myLinearLayout = findViewById(R.id.my_linear_layout);


        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, // width
                LinearLayout.LayoutParams.MATCH_PARENT  // height
        );

        ImageButton sendtosettingsbutton = findViewById(R.id.sendtosetting);
        sendtosettingsbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Inventory.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        ImageButton sendtomainpagebutton = findViewById(R.id.sendtomainpage);
        sendtomainpagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Inventory.this, Screentwo.class);
                startActivity(intent);
            }
        });

        ImageButton sentoworkoutbutton = findViewById(R.id.sendtoworkout);
        sentoworkoutbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Inventory.this, ExcerciseActivity.class);
                startActivity(intent);
            }
        });

        ImageButton sendToShop = findViewById(R.id.sendtoshop);
        sendToShop.setOnClickListener(v -> {
            Intent intent = new Intent(Inventory.this, Shop.class);
            startActivity(intent);
        });

        ImageButton sendtoInventory = findViewById(R.id.sendtolibray);
        sendtoInventory.setOnClickListener(v -> {
            Intent intent = new Intent(Inventory.this, Inventory.class);
            startActivity(intent);
        });

        Acorns app = (Acorns) getApplication();
        items_in_inventory_for_display = app.getinventory();

        ArrayList<ImageButton> buttons = new ArrayList<>();

        ImageButton newImageButton = new ImageButton(this);
        if (items_in_inventory_for_display.contains("wizardhat")){
            int drawableResId = getIntent().getIntExtra("@wizardkhat_inventoryicon", 0);
            setlayoutconstraints(newImageButton, drawableResId);
            set_the_equipped_hat(newImageButton, drawableResId, 1);

        }

    }
    public void setlayoutconstraints(ImageButton item, @DrawableRes int itemimage) {

        LinearLayout myLinearLayout = findViewById(R.id.my_linear_layout);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, // width
                LinearLayout.LayoutParams.MATCH_PARENT  // height
        );
        item.setImageResource(itemimage);
        item.setLayoutParams(layoutParams);
        myLinearLayout.addView(item);
    }
    public void set_the_equipped_hat(ImageButton item, @DrawableRes int itemimage, int numberforimageusespecific){
        if (item != null) {
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ImageView characterfoxthing = findViewById(R.id.wizard_hat_outfit);
                    //this only sets it so the program doesn't crash
                    int numberforimageuse = numberforimageusespecific;
                    switch (numberforimageuse){
                        case 1:
                            characterfoxthing = findViewById(R.id.wizard_hat_outfit);
                            break;
                    }
                    if (!equippedhat) {
                        characterfoxthing.setImageResource(itemimage);
                        equippedhat = true;
                    }else {
                        equippedhat = false;
                        characterfoxthing.setImageDrawable(null);
                    }
                }
            });
        }
    }

}

