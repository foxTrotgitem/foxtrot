package com.example.foxtrot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class WorkoutGraphView extends View {

    private Paint linePaint;
    private Paint axisPaint;
    private Paint textPaint;
    private Path graphPath;

    private List<Float> timeData = new ArrayList<>();
    private List<Float> stepData = new ArrayList<>();

    private float maxTime = 0;
    private float maxSteps = 0;

    public WorkoutGraphView(Context context) {
        super(context);
        init();
    }

    public WorkoutGraphView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public WorkoutGraphView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        linePaint = new Paint();
        linePaint.setColor(Color.parseColor("#CC9554"));
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(8f);
        linePaint.setAntiAlias(true);

        axisPaint = new Paint();
        axisPaint.setColor(Color.GRAY);
        axisPaint.setStrokeWidth(4f);
        axisPaint.setAntiAlias(true);

        textPaint = new Paint();
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(30f);
        textPaint.setAntiAlias(true);

        graphPath = new Path();
    }

    public void setData(String jsonData) {
        timeData.clear();
        stepData.clear();
        maxTime = 0;
        maxSteps = 0;

        try {
            JSONArray history = new JSONArray(jsonData);
            for (int i = 0; i < history.length(); i++) {
                JSONObject entry = history.getJSONObject(i);
                if (entry.has("time") && entry.has("steps")) {
                    float time = (float) entry.getDouble("time");
                    float steps = (float) entry.getDouble("steps");

                    timeData.add(time);
                    stepData.add(steps);

                    if (time > maxTime) maxTime = time;
                    if (steps > maxSteps) maxSteps = steps;
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (timeData.size() < 2) {
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Not enough data for a graph.", getWidth() / 2f, getHeight() / 2f, textPaint);
            return;
        }

        float padding = 120f; // Increased padding for better spacing
        float drawableWidth = getWidth() - (2 * padding);
        float drawableHeight = getHeight() - (2 * padding);

        // Draw X and Y axes
        canvas.drawLine(padding, getHeight() - padding, getWidth() - padding, getHeight() - padding, axisPaint); // X-axis
        canvas.drawLine(padding, padding, padding, getHeight() - padding, axisPaint); // Y-axis

        // --- Draw main axis labels ---
        textPaint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("Time", getWidth() / 2f, getHeight() - padding + 80, textPaint);
        canvas.save();
        canvas.rotate(-90, padding - 80, getHeight() / 2f);
        canvas.drawText("Steps", padding - 80, getHeight() / 2f, textPaint);
        canvas.restore();

        // --- Draw Y-axis (Steps) labels ---
        textPaint.setTextAlign(Paint.Align.RIGHT);
        int yLabelCount = 5; // Number of labels on the Y-axis
        for (int i = 0; i <= yLabelCount; i++) {
            if (maxSteps > 0) { // Avoid division by zero and pointless labels if no steps
                float stepValue = (maxSteps / yLabelCount) * i;
                String label = String.valueOf((int) stepValue);
                float y = (getHeight() - padding) - ((stepValue / maxSteps) * drawableHeight);
                canvas.drawText(label, padding - 20, y + (textPaint.getTextSize() / 2), textPaint);
            }
        }

        // --- Draw X-axis (Time) labels ---
        textPaint.setTextAlign(Paint.Align.CENTER);
        int xLabelCount = 5; // Number of labels on the X-axis
        for (int i = 0; i <= xLabelCount; i++) {
            if(maxTime > 0) {
                float timeValue = (maxTime / xLabelCount) * i;
                String label = (int) timeValue + "s";
                float x = padding + ((timeValue / maxTime) * drawableWidth);
                canvas.drawText(label, x, getHeight() - padding + 50, textPaint);
            }
        }

        // Reset alignment
        textPaint.setTextAlign(Paint.Align.LEFT);

        // --- Draw the graph line ---
        graphPath.reset();

        float firstX = padding;
        float firstY = getHeight() - padding;
        if (stepData.size() > 0 && maxSteps > 0) {
            firstY = (getHeight() - padding) - (stepData.get(0) / maxSteps) * drawableHeight;
        }
        graphPath.moveTo(firstX, firstY);

        for (int i = 0; i < timeData.size(); i++) {
            float x = padding;
            if (maxTime > 0) {
                 x = padding + (timeData.get(i) / maxTime) * drawableWidth;
            }
            float y = getHeight() - padding;
            if (maxSteps > 0) {
                y = (getHeight() - padding) - (stepData.get(i) / maxSteps) * drawableHeight;
            }
            graphPath.lineTo(x, y);
        }

        canvas.drawPath(graphPath, linePaint);
    }
}
