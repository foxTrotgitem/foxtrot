package com.example.foxtrot;


import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.List;


public class popup_buy_item_fragment extends Fragment {


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        final View view = inflater.inflate(R.layout.fragment_popup_to_buy_item, container, false);
        return view;
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        Button closeButton = view.findViewById(R.id.deletefragment);
        closeButton.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager().beginTransaction()
                    .remove(this)
                    .commit();
        });


        Button buyitemforrealfinal = view.findViewById(R.id.buyitemforreal);
        buyitemforrealfinal.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(getActivity(), ThanksForBuying.class);
                Acorns app = (Acorns) getActivity().getApplication();
                app.addtoinventory();
                saveData();
                startActivity(intent);
            }
        });


    }
    private com.example.foxtrot.FoxData db;
    private String TAg = getClass().getSimpleName();

    private void saveData() {
        Acorns app = (Acorns) getActivity().getApplication();


        final String items = app.getItembeingbought();
        db = com.example.foxtrot.FoxData.getInstance(getContext());


        new Thread (new Runnable() {
            @Override
            public void run(){
                InventoryInfo inventoryinfo = new InventoryInfo(items, false);
                InventoryDAO dao = db.getFoxDataDAOForInventory();
                dao.insertInventoryInfo(inventoryinfo);
                List<InventoryInfo> people = dao.listInventoryInfo();
            }
        }).start();
    }
}
