package com.example.foxtrot;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
//tod did this, a little bit of dan too
public class SignUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        Button continueButton=findViewById(R.id.bbutton);
        EditText emailField=findViewById(R.id.editEmail);
        EditText passwordField=findViewById(R.id.editPassword);
        EditText confirmPasswordField=findViewById(R.id.editTextText3);
        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this code is Dan
                String email=emailField.getText().toString().trim();
                String password=passwordField.getText().toString().trim();
                if(TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    Toast.makeText(SignUp.this, "Please input a valid email!", Toast.LENGTH_SHORT).show();                }
                else if((TextUtils.isEmpty(password))||(password.length()<8)){
                    Toast.makeText(SignUp.this, "Please input a password!", Toast.LENGTH_SHORT).show();                    return;
                }
                else{
                    Toast.makeText(SignUp.this, "Sign up Successful!", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(SignUp.this, information.class);
                    //fixed code
                    startActivity(intent);
                }
            }
        });
    }
}