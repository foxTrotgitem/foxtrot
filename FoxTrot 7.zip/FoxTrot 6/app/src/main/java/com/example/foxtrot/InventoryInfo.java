package com.example.foxtrot;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;



@Entity(tableName = "inventoryinfo")
public class InventoryInfo {
    @PrimaryKey(autoGenerate = true)
    @NonNull public int uid;
    @ColumnInfo
    public String itemname;
    public boolean equipped;

    public InventoryInfo(String item, boolean equip){
        itemname = item;
        equipped = equip;
    }
    public InventoryInfo() {}
}

