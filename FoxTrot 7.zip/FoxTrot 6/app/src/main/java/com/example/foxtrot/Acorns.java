package com.example.foxtrot; // Replace with your package name

import android.app.Application;

import java.util.ArrayList;
import java.util.Map;

public class Acorns extends Application {
//this was all Zach
    private int myGlobalAcorns;
    private int price;
    private String itembeingbought;
    private ArrayList<String> items_in_inventory = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        // Initialize your global variables here, so it only does it once!

        myGlobalAcorns = 0;

    }
    // Getter methods to access your global variables

    //setting the amount of acorns
    public int getAcorns() {
        return myGlobalAcorns;
    }
    public void addtotheAcorns(int myGlobalInt) {
        this.myGlobalAcorns += myGlobalInt;
    }


    //setting the price that takes away from total acorns
    public void setprice(int price) {
        this.price = price;
    }
    public int getprice() {
        return price;
    }

    //Zach
    //God had left us in this world. Only code remains
    //getting the name of the item currently being bought
    public void setcurrentitembeingbought(String item) {
        this.itembeingbought = item;
    }

    public String getItembeingbought(){
        return itembeingbought;
    }

    public void addtoinventory() {
        items_in_inventory.add(itembeingbought);
    }

    public ArrayList<String> getinventory() {
        return items_in_inventory;
    }

}

