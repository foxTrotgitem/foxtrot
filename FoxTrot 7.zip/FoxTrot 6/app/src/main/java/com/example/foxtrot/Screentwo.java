package com.example.foxtrot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Screentwo extends AppCompatActivity{
    //hey all, tod here! AAAAAAAA
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_screentwo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) ->{
            Insets systemBars=insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button bringToShop=findViewById(R.id.bringToShop);
        bringToShop.setOnClickListener(v ->{
            Intent intent=new Intent(Screentwo.this, Shop.class);
            startActivity(intent);
        });

        ImageButton itemA=findViewById(R.id.ItemA);
        itemA.setOnClickListener(v ->{
            Intent intent=new Intent(Screentwo.this, Shop.class);
            startActivity(intent);
        });

        ImageView exerciseBring=findViewById(R.id.exercise_bring);
        exerciseBring.setOnClickListener(v ->{
            Intent intent=new Intent(Screentwo.this, AddExerciseActivity.class);
            startActivity(intent);
        });

        ImageButton sendToShop=findViewById(R.id.sendtoshop);
        sendToShop.setOnClickListener(v ->{
            Intent intent=new Intent(Screentwo.this, Shop.class);
            startActivity(intent);
        });

        ImageButton sendToWorkout=findViewById(R.id.sendtoworkout);
        sendToWorkout.setOnClickListener(v ->{
            Intent intent=new Intent(Screentwo.this, ExcerciseActivity.class);
            startActivity(intent);
        });

        ImageButton sendToSettings=findViewById(R.id.sendtosetting);
        sendToSettings.setOnClickListener(v ->{
            Intent intent=new Intent(Screentwo.this, SettingsActivity.class);
            startActivity(intent);
        });

        ImageButton sendToMainPage=findViewById(R.id.sendtomainpage);
        sendToMainPage.setOnClickListener(v ->{
            Intent intent=new Intent(Screentwo.this, Screentwo.class);
            startActivity(intent);
        });
    }
}
