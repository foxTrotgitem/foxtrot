//I screwed up everything and had to import everything manually... oops... -m-
package com.example.foxtrot;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText; // Import EditText
import android.widget.Toast; // Import Toast for user feedback
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.foxtrot.Screentwo;

public class LoginScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //this on create stuff is Zach
        //so this all above is just the normal stuff we know and love, nothing changes too much except for some imports.
//hi tod did a bit too :3
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);//this makes the shared preferences work that allows for the value to only appear once
        SharedPreferences.Editor editor = sharedPref.edit();

        String yourVariable = sharedPref.getString(getString(R.string.nameOfValue), getString(R.string.defaultValue));
        Bundle acornBaggie = new Bundle();

        if (yourVariable.equals(getString(R.string.defaultValue))) //app was run for 1st time
        {
            Acorns app = (Acorns) getApplication();
            app.addtotheAcorns( 1000 );
        }
        EdgeToEdge.enable(this);
        setContentView(R.layout.loginscreen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get references to your EditText fields
        EditText emailField = findViewById(R.id.editEmail);
        EditText passwordField = findViewById(R.id.editPassword);
        Button loginButton = findViewById(R.id.abutton);

        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //this email code was Dan
                // Get the text from the fields
                String email = emailField.getText().toString().trim();
                String password = passwordField.getText().toString().trim();

                if(TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    emailField.setError("Please enter a valid email address");
                    return; // Stop the login process
                }

                if(TextUtils.isEmpty(password)){
                    passwordField.setError("Password cannot be empty");
                    return; // Stop the login process
                }

                else {
                    Toast.makeText(LoginScreen.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginScreen.this, Screentwo.class);
                    startActivity(intent);
                }
            }
        });
        Button signUpButton = findViewById(R.id.button2);
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginScreen.this, SignUp.class);
                startActivity(intent);
            }
        });
    }
}