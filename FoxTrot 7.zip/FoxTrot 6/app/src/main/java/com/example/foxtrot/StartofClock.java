package com.example.foxtrot;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
//here we FUCKING go
import java.util.Locale;
//this is all tod
public class StartofClock extends AppCompatActivity {

    private TextView timerTextView;
    private CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_startof_clock);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        timerTextView = findViewById(R.id.textView7);

        Intent intent = getIntent();
        long timerDuration = intent.getLongExtra("TIMER_DURATION", 0);

        if (timerDuration > 0) {
            countDownTimer = new CountDownTimer(timerDuration, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    long minutes = (millisUntilFinished / 1000) / 60;
                    long seconds = (millisUntilFinished / 1000) % 60;
                    String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
                    timerTextView.setText(timeLeftFormatted);
                }

                @Override
                public void onFinish() {
                    timerTextView.setText("Good job! You Gained x Acorns");
                }
            }.start();
        }
    }
}
