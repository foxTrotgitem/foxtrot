package com.example.foxtrot;




import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Entity;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;


import java.util.List;


@Dao
interface InventoryDAO {
    @Insert
    void insertInventoryInfo(InventoryInfo item);


    @Update
    void updateInventoryInfo(InventoryInfo item);


    @Delete
    void deleteInventoryInfo(InventoryInfo item);


    @Query("SELECT * FROM inventoryinfo")
    public List<InventoryInfo> listInventoryInfo();










}

