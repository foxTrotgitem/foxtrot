package com.example.foxtrot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class YouDidItActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.youdidit);

        Button nextButton=findViewById(R.id.nextButton);
        nextButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(YouDidItActivity.this, ResultsActivity.class);
                long duration=getIntent().getLongExtra("TIMER_DURATION", 0);
                int stepCount=getIntent().getIntExtra("STEP_COUNT", 0);
                String graphData = getIntent().getStringExtra("GRAPH_DATA");

                intent.putExtra("TIMER_DURATION", duration);
                intent.putExtra("STEP_COUNT", stepCount);
                intent.putExtra("GRAPH_DATA", graphData);
                startActivity(intent);
            }
        });
    }
}