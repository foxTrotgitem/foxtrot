package com.example.foxtrot;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


public class Shop extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_shop);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



        //This is the code for sending to different screens
        ImageButton sendtosettingsbutton = findViewById(R.id.sendtosetting);
        sendtosettingsbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Shop.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        ImageButton sendtomainpagebutton = findViewById(R.id.sendtomainpage);
        sendtomainpagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Shop.this, Screentwo.class);
                startActivity(intent);
            }
        });

        ImageButton sentoworkoutbutton = findViewById(R.id.sendtoworkout);
        sentoworkoutbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Shop.this, ExcerciseActivity.class);
                startActivity(intent);
            }
        });

        ImageButton sendToShop = findViewById(R.id.sendtoshop);
        sendToShop.setOnClickListener(v -> {
            Intent intent = new Intent(Shop.this, Shop.class);
            startActivity(intent);
        });


        //buttons for buying items
        //Zach
        ImageButton buyitemfromshop = findViewById(R.id.ItemA1);
        buyitemfromshop.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                setItemsToSend("wizardshirt", 300);
            }
        });

        ImageButton buyitemfromshop1 = findViewById(R.id.ItemA2);
        buyitemfromshop1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                setItemsToSend("wizardhat", 100);

            }
        });

        ImageButton buyitemfromshop2 = findViewById(R.id.ItemB1);
        buyitemfromshop2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                setItemsToSend("spaceshirt_shirt", 300);

            }
        });

        ImageButton buyitemfromshop3 = findViewById(R.id.ItemB2);
        buyitemfromshop3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                setItemsToSend("spacesuit_head", 100);

            }
        });

        ImageButton buyitemfromshop4 = findViewById(R.id.ItemC1);
        buyitemfromshop4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                setItemsToSend("steampunk_shirt", 300);

            }
        });

        ImageButton buyitemfromshop5 = findViewById(R.id.ItemC2);
        buyitemfromshop5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                setItemsToSend("steampunk_head", 200);

            }
        });

        ImageButton sendtoInventory = findViewById(R.id.sendtolibray);
        sendtoInventory.setOnClickListener(v -> {
            Intent intent = new Intent(Shop.this, Inventory.class);
            startActivity(intent);
        });






        //displays the current amount of acorns
        Acorns app = (Acorns) getApplication();
        int globalacorns = app.getAcorns();
        TextView acornsText = findViewById(R.id.numberofAcorns);
        acornsText.setText(String.valueOf(globalacorns));

    }
    public void setItemsToSend( String setitemImage, int itemprice)
    {
        //Zach
        //Sends value to next screen
        Intent intent = new Intent(Shop.this, BuyItem.class);
        Bundle itemtobuy = new Bundle();
        itemtobuy.putString("itemimage", setitemImage);
        itemtobuy.putInt("price", itemprice);
        intent.putExtras(itemtobuy);
        startActivity(intent);
    }


}
