package com.example.foxtrot;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class StartWorkoutActivity extends AppCompatActivity implements SensorEventListener {

    private static final int ACTIVITY_RECOGNITION_REQUEST_CODE = 100;
    private TextView timerTextView;
    private TextView stepCountTextView;
    private long duration;
    private SensorManager sensorManager;
    private Sensor stepCounterSensor;
    private int stepCount = 0;
    private int initialStepCount = -1; // To store the initial step count

    // Lists to store data for the line graph
    private ArrayList<Integer> stepDataList = new ArrayList<>();
    private ArrayList<Long> timeDataList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_workout);

        timerTextView = findViewById(R.id.timer_textview);
        stepCountTextView = findViewById(R.id.step_count_textview);

        duration = getIntent().getLongExtra("TIMER_DURATION", 0);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        if (stepCounterSensor == null) {
            Toast.makeText(this, "Step counter sensor not available!", Toast.LENGTH_SHORT).show();
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.ACTIVITY_RECOGNITION},
                            ACTIVITY_RECOGNITION_REQUEST_CODE);
                }
            }
        }

        new CountDownTimer(duration, 1000){
            public void onTick(long millisUntilFinished){
                long minutes = (millisUntilFinished / 1000) / 60;
                long seconds = (millisUntilFinished / 1000) % 60;
                timerTextView.setText(String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds));

                // Record data for the graph at each tick
                long elapsedTime = duration - millisUntilFinished;
                stepDataList.add(stepCount);
                timeDataList.add(elapsedTime);
            }

            public void onFinish(){
                timerTextView.setText("Done!");
                Intent intent = new Intent(StartWorkoutActivity.this, YouDidItActivity.class);

                // Create a JSON array of the workout data for the graph
                JSONArray graphData = new JSONArray();
                for (int i = 0; i < stepDataList.size(); i++) {
                    try {
                        JSONObject dataPoint = new JSONObject();
                        dataPoint.put("time", timeDataList.get(i) / 1000); // time in seconds
                        dataPoint.put("steps", stepDataList.get(i));
                        graphData.put(dataPoint);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                intent.putExtra("TIMER_DURATION", duration);
                intent.putExtra("STEP_COUNT", stepCount);
                intent.putExtra("GRAPH_DATA", graphData.toString());
                startActivity(intent);
            }
        }.start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (stepCounterSensor != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION)
                        == PackageManager.PERMISSION_GRANTED) {
                    sensorManager.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_UI);
                }
            } else {
                sensorManager.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_UI);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (stepCounterSensor != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            int totalSteps = (int) event.values[0];
            if (initialStepCount == -1) {
                initialStepCount = totalSteps;
            }
            stepCount = totalSteps - initialStepCount;
            stepCountTextView.setText("Steps: " + stepCount);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed for this implementation
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == ACTIVITY_RECOGNITION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
            } else {
                Toast.makeText(this, "Permission for activity recognition denied. Step counter will not work.", Toast.LENGTH_LONG).show();
            }
        }
    }
}