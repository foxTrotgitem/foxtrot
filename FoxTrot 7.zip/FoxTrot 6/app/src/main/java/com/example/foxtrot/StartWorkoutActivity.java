package com.example.foxtrot;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;
//this is all Tod
public class StartWorkoutActivity extends AppCompatActivity {

    private TextView timerTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_workout);

        timerTextView = findViewById(R.id.timer_textview);

        long duration = getIntent().getLongExtra("TIMER_DURATION", 0);

        new CountDownTimer(duration, 1000) {
            public void onTick(long millisUntilFinished) {
                long minutes = (millisUntilFinished / 1000) / 60;
                long seconds = (millisUntilFinished / 1000) % 60;
                timerTextView.setText(String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds));
            }

            public void onFinish() {
                timerTextView.setText("Done!");
            }
        }.start();
    }
}