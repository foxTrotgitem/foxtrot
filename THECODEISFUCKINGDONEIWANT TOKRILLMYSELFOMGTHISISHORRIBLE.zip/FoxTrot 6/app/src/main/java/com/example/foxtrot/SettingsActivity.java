package com.example.foxtrot;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageButton sendToShop = findViewById(R.id.sendtoshop);
        sendToShop.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, Shop.class);
            startActivity(intent);
        });

        ImageButton sendToWorkout = findViewById(R.id.sendtoworkout);
        sendToWorkout.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, ExcerciseActivity.class);
            startActivity(intent);
        });

        ImageButton sendToSettings = findViewById(R.id.sendtosetting);
        sendToSettings.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        ImageButton sendToMainPage = findViewById(R.id.sendtomainpage);
        sendToMainPage.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, Screentwo.class);
            startActivity(intent);
        });

        ImageButton sendtoInventory = findViewById(R.id.sendtolibray);
        sendtoInventory.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, Inventory.class);
            startActivity(intent);
        });
    }
}
