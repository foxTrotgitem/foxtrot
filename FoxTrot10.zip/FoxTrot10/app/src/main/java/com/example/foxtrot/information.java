package com.example.foxtrot;
//tod did this, i also made sure the screen worked
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;

public class information extends AppCompatActivity{
    private FoxData db;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.information);
        db = FoxData.getInstance(this);

        EditText heightField=findViewById(R.id.editHeight);

        //what does this mean
        AutoCompleteTextView autoCompleteTextView=findViewById(R.id.limitation_autocomplete_text);
        String[] limitationOptions=getResources().getStringArray(R.array.limitation_options);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(
                this,
                //this what. THIS WHAT, WHAT DOES THIS MEAN, WHAT THE HELL DOES THIS MENA
                android.R.layout.simple_dropdown_item_1line,
                limitationOptions
        );
        autoCompleteTextView.setAdapter(adapter);
        Button done=findViewById(R.id.cbutton);
        done.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                saveHeight();
                Intent intent=new Intent(information.this, Screentwo.class);
                startActivity(intent);
            }
            //thank you relah
        });
    }

    private void saveHeight() {
        EditText heightField = findViewById(R.id.editHeight);
        String heightText = heightField.getText().toString();
        if (!heightText.isEmpty()) {
            int height = Integer.parseInt(heightText);
            new Thread(() -> {
                InformationDAO dao = db.getFoxDataDAO();
                UserInfo user = dao.listUserInfo().get(0); // Assuming a single user
                user.height = height;
                dao.updateUserInfo(user);
            }).start();
        }
    }
}