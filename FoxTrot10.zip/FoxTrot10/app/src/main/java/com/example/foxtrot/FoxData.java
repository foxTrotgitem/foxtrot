package com.example.foxtrot;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {UserInfo.class}, version = 6)
public abstract class FoxData extends RoomDatabase {

    private static FoxData minstance;
    private static final String DB_NAME = "person_db";

    public abstract InformationDAO getFoxDataDAO();

    public static synchronized FoxData getInstance(Context ctx) {
        if (minstance == null){
            minstance = Room.databaseBuilder(ctx.getApplicationContext(), FoxData.class, DB_NAME)
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return minstance;
    }

}
