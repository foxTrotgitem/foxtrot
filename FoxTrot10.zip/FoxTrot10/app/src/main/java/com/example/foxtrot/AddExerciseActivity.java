package com.example.foxtrot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
//hi all, tod here, gonna cry!
public class AddExerciseActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_exercise);
        EditText exerciseNameInput=findViewById(R.id.exercise_name_input);
        EditText exerciseTimeInput=findViewById(R.id.exercise_time_input);
        Button saveExerciseButton=findViewById(R.id.save_exercise_button);
        saveExerciseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String exerciseName=exerciseNameInput.getText().toString();
                int exerciseTime=Integer.parseInt(exerciseTimeInput.getText().toString());
                Intent resultIntent=new Intent();
                resultIntent.putExtra("exercise_name", exerciseName);
                resultIntent.putExtra("exercise_time", exerciseTime);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}