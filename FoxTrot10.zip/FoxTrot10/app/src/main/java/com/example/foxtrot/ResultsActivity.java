package com.example.foxtrot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class ResultsActivity extends AppCompatActivity {

    private WorkoutGraphView graphView;
    private TextView totalStepsTextView;
    private TextView acornsTextView;
    private TextView distanceTextView;
    private FoxData db;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.results);

        long duration = getIntent().getLongExtra("TIMER_DURATION", 0);
        int stepCount = getIntent().getIntExtra("STEP_COUNT", 0);
        String graphData = getIntent().getStringExtra("GRAPH_DATA");

        long minutes = duration / 1000 / 60;
        int acornsEarned = (int) minutes * 10;

        acornsTextView = findViewById(R.id.acorns);
        acornsTextView.setText(String.valueOf(acornsEarned));

        Acorns app = (Acorns) getApplication();
        app.addtotheAcorns(acornsEarned);

        graphView = findViewById(R.id.steps_chart);
        totalStepsTextView = findViewById(R.id.steps_textview);
        totalStepsTextView.setText(String.valueOf(stepCount));

        distanceTextView = findViewById(R.id.Distance);
        db = FoxData.getInstance(this);

        updateDistance();

        if (graphData != null) {
            graphView.setData(graphData);
        }

        Button returnButton = findViewById(R.id.returnButton);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultsActivity.this, Screentwo.class);
                startActivity(intent);
            }
        });
    }

    private void updateDistance() {
        new Thread(() -> {
            InformationDAO dao = db.getFoxDataDAO();
            if (dao.listUserInfo() != null && !dao.listUserInfo().isEmpty()) {
                UserInfo user = dao.listUserInfo().get(0); // Assuming a single user
                int height = user.height;
                int stepNum = getIntent().getIntExtra("STEP_COUNT", 0);

                if (height > 0 && stepNum > 0) {

                    double inchDistance = height * 0.413 * stepNum;
                    double distance = inchDistance / 12;

                    runOnUiThread(() -> {
                        distanceTextView.setText(String.format(Locale.US, "%.2f ft", distance));
                    });
                } else {
                    runOnUiThread(() -> {
                        distanceTextView.setText("0.00 ft");
                    });
                }
            }
        }).start();
    }
}