package com.example.foxtrot;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler; // Using a Handler for periodic saving
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

public class StepCounter extends AppCompatActivity implements SensorEventListener {
    //Gesin, I'll be honest. I had no clue what to due with the graph so gemini did some wizard magic tomfoolery
    //Now, only God knows how the graph stuff works
    private SensorManager sensorManager;
    private Sensor stepCounterSensor;

    private int totalSteps = 0;
    private int initialSteps = -1; // Use -1 to indicate it's not set yet
    private TextView stepsTextView;

    // --- NEW: Logic for workout session graphing ---
    private Handler graphDataHandler = new Handler();
    private JSONArray workoutHistory; // Stores the (time, steps) points for the current workout
    private long workoutStartTime;
    private static final long SAVE_INTERVAL_MS = 1000; // Save a data point every 5 seconds

    // --- SharedPreferences constants ---
    private static final String PREFS_NAME = "StepCounterPrefs";
    private static final String WORKOUT_HISTORY_KEY = "WorkoutStepHistory";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.results);

        stepsTextView = findViewById(R.id.steps_textview);
        stepsTextView.setText("0"); // Start display at 0

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        if (stepCounterSensor == null) {
            Toast.makeText(this, "Step Counting is not available on this device.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            int currentSteps = (int) event.values[0];

            if (initialSteps == -1) {
                initialSteps = currentSteps;
            }

            totalSteps = currentSteps - initialSteps;

            stepsTextView.setText(String.valueOf(totalSteps));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Nothing needed here... yet...
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (stepCounterSensor != null) {
            sensorManager.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_UI);

            startWorkoutTracking();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager != null) {
            // Unregister the sensor to save battery
            sensorManager.unregisterListener(this);

            //Stop tracking and save the final data
            stopWorkoutTracking();
        }
    }

    // --- Methods for In-Workout Graphing ---

    /**
     * Initializes variables and starts the periodic saving process for graph data.
     */
    private void startWorkoutTracking() {
        workoutStartTime = System.currentTimeMillis();
        workoutHistory = new JSONArray(); // Reset history for the new session
        graphDataHandler.post(saveDataRunnable); // Start the runnable
    }

    /**
     * The Runnable that saves a (time, steps) data point every SAVE_INTERVAL_MS.
     */
    private Runnable saveDataRunnable = new Runnable() {
        @Override
        public void run() {
            try {
                // keeps track of time for gemini's voodoo magic graph
                long timeElapsedSeconds = (System.currentTimeMillis() - workoutStartTime) / 1000;

                // Create a new data point
                JSONObject entry = new JSONObject();
                entry.put("time", timeElapsedSeconds);
                entry.put("steps", totalSteps);
                workoutHistory.put(entry);

                // Schedule the next save
                graphDataHandler.postDelayed(this, SAVE_INTERVAL_MS);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    /**
     * Stops the periodic saving and stores the final workout data to SharedPreferences.
     */
    private void stopWorkoutTracking() {
        graphDataHandler.removeCallbacks(saveDataRunnable); // Stop the periodic saving

        // Save the complete workout history to SharedPreferences
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(WORKOUT_HISTORY_KEY, workoutHistory.toString());
        editor.apply();

        // Optional: Toast to confirm data is saved
        Toast.makeText(this, "Workout data saved!", Toast.LENGTH_SHORT).show();
    }


    /**
     * Call this method from your graph activity to get the last workout's data.
     * It returns a JSON-formatted string like: "[{"time":5,"steps":20},{"time":10,"steps":45},...]".
     */
    public String getWorkoutHistoryForGraph() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getString(WORKOUT_HISTORY_KEY, "[]");
    }
}
