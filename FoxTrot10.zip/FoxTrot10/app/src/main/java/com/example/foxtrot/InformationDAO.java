package com.example.foxtrot;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Entity;
import androidx.room.Insert;
import androidx.room.PrimaryKey;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
@Entity(tableName="userInfo")
//public class screenSkip{
    //@PrimaryKey(autoGenerate = true)
    //public boolean skipCheck;
    //public void setSkipCheck(boolean skipCheck) {
    //    this.skipCheck = skipCheck;
  //  }
    //public boolean getSkipCheck() {
      //  return skipCheck;
    //}
//}
@Dao
interface InformationDAO {
    @Insert
    void insertUserInfo(UserInfo userInfo);

    @Update
    void updateUserInfo(UserInfo userInfo);

    @Delete
    void deleteUserInfo(UserInfo userInfo);

    @Query("SELECT * FROM userInfo")
    public List<UserInfo> listUserInfo();
    @Query("SELECT skipLogin FROM userInfo")
    public boolean skipCheck();
}
