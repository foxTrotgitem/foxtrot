package com.example.foxtrot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class Inventory extends AppCompatActivity {

    private boolean equippedhat = false;
    private boolean equippedshirt = false;

    private ArrayList <String> items_in_inventory_for_display = new ArrayList<>();


    @Override
    //Simba everything you see here was made by Zachary "About to die of exhaustion" Pressler. May his soul find eternal rest in the after life
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        LinearLayout myLinearLayout = findViewById(R.id.my_linear_layout);


        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, // width
                LinearLayout.LayoutParams.MATCH_PARENT  // height
        );

        Acorns app = (Acorns) getApplication();
        items_in_inventory_for_display = app.getinventory();

        //wizardhat icon on screen
        ImageButton newImageButton = new ImageButton(this);
        if (items_in_inventory_for_display.contains("wizardhat")){
            newImageButton.setImageResource(R.drawable.wizardkhat_inventoryicon);
            newImageButton.setLayoutParams(layoutParams);
            myLinearLayout.addView(newImageButton);
        }
        if (newImageButton != null) {
            newImageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ImageView characterfoxthing = findViewById(R.id.characterfoxhat);
                    if (!equippedhat) {
                        characterfoxthing.setImageResource(R.drawable.wizadhat_overthefox);
                        equippedhat = true;
                    }else {
                        equippedhat = false;
                        characterfoxthing.setImageDrawable(null);
                    }
                }
            });
        }


        //wizardshirt icon on screen
        ImageButton newImageButton2 = new ImageButton(this);
        if (items_in_inventory_for_display.contains("wizardshirt")){
            newImageButton2.setImageResource(R.drawable.wizardrobes_inventoryicon);
            newImageButton2.setLayoutParams(layoutParams);
            myLinearLayout.addView(newImageButton2);
        }
        if (newImageButton2 != null) {
            newImageButton2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ImageView characterfoxthing = findViewById(R.id.characterfoxshirt);
                    if (!equippedshirt) {
                        characterfoxthing.setImageResource(R.drawable.wizardshirt_overfox);
                        equippedshirt = true;
                    }else {
                        equippedshirt = false;
                        characterfoxthing.setImageDrawable(null);
                    }
                }
            });
        }


        //spaceshirt icon on screen
        ImageButton newImageButton3 = new ImageButton(this);
        if (items_in_inventory_for_display.contains("spaceshirt_shirt")){
            newImageButton3.setImageResource(R.drawable.spaceshirt_inventoryicon);
            newImageButton3.setLayoutParams(layoutParams);
            myLinearLayout.addView(newImageButton3);
        }
        if (newImageButton3 != null) {
            newImageButton3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ImageView characterfoxthing = findViewById(R.id.characterfoxshirt);
                    if (!equippedshirt) {
                        characterfoxthing.setImageResource(R.drawable.only_spaceshirt);
                        equippedshirt = true;
                    }else {
                        equippedshirt = false;
                        characterfoxthing.setImageDrawable(null);
                    }
                }
            });
        }


        //spacehead icon on screen
        ImageButton newImageButton4 = new ImageButton(this);
        if (items_in_inventory_for_display.contains("spacesuit_head")){
            newImageButton4.setImageResource(R.drawable.spacehat_inventoryicon);
            newImageButton4.setLayoutParams(layoutParams);
            myLinearLayout.addView(newImageButton4);
        }
        if (newImageButton4 != null) {
            newImageButton4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ImageView characterfoxthing = findViewById(R.id.characterfoxhat);
                    if (!equippedhat) {
                        characterfoxthing.setImageResource(R.drawable.only_spacehat);
                        equippedhat = true;
                    }else {
                        equippedhat = false;
                        characterfoxthing.setImageDrawable(null);
                    }
                }
            });
        }


        //steampunkshirt icon on screen
        ImageButton newImageButton5 = new ImageButton(this);
        if (items_in_inventory_for_display.contains("steampunk_shirt")){
            newImageButton5.setImageResource(R.drawable.steampunkshirt_inventoryicon);
            newImageButton5.setLayoutParams(layoutParams);
            myLinearLayout.addView(newImageButton5);
        }
        if (newImageButton5 != null) {
            newImageButton5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ImageView characterfoxthing = findViewById(R.id.characterfoxshirt);
                    if (!equippedshirt) {
                        characterfoxthing.setImageResource(R.drawable.only_steampunkshirt);
                        equippedshirt = true;
                    }else {
                        equippedshirt = false;
                        characterfoxthing.setImageDrawable(null);
                    }
                }
            });
        }



        ImageButton newImageButton6 = new ImageButton(this);
        if (items_in_inventory_for_display.contains("steampunk_head")){
            newImageButton6.setImageResource(R.drawable.steampunkhat_inventoryicon);
            newImageButton6.setLayoutParams(layoutParams);
            myLinearLayout.addView(newImageButton6);
        }
        if (newImageButton6 != null) {
            newImageButton6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ImageView characterfoxthing = findViewById(R.id.characterfoxhat);
                    if (!equippedhat) {
                        characterfoxthing.setImageResource(R.drawable.only_steampunkhat);
                        equippedhat = true;
                    }else {
                        equippedhat = false;
                        characterfoxthing.setImageDrawable(null);
                    }
                }
            });
        }



        ImageButton sendtosettingsbutton = findViewById(R.id.sendtosetting);
        sendtosettingsbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Inventory.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        ImageButton sendtomainpagebutton = findViewById(R.id.sendtomainpage);
        sendtomainpagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Inventory.this, Screentwo.class);
                startActivity(intent);
            }
        });

        ImageButton sentoworkoutbutton = findViewById(R.id.sendtoworkout);
        sentoworkoutbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Inventory.this, ExcerciseActivity.class);
                startActivity(intent);
            }
        });

        ImageButton sendToShop = findViewById(R.id.sendtoshop);
        sendToShop.setOnClickListener(v -> {
            Intent intent = new Intent(Inventory.this, Shop.class);
            startActivity(intent);
        });

        ImageButton sendtoInventory = findViewById(R.id.sendtoinventory);
        sendtoInventory.setOnClickListener(v -> {
            Intent intent = new Intent(Inventory.this, Inventory.class);
            startActivity(intent);
        });


    }
    public void setthelinearlayoutwithitem( ImageButton item){

    }


}
