package com.example.foxtrot; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;

public class information extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.information);
        AutoCompleteTextView autoCompleteTextView = findViewById(R.id.limitation_autocomplete_text);
        String[] limitationOptions = getResources().getStringArray(R.array.limitation_options);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                limitationOptions
        );
        autoCompleteTextView.setAdapter(adapter);
        Button done = findViewById(R.id.cbutton);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(information.this, Screentwo.class);
                startActivity(intent);
            }
        });
    }
}