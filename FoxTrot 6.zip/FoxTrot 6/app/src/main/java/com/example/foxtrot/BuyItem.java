package com.example.foxtrot;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


public class BuyItem extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_buy_item);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        ImageButton confirmpurchasequestion = findViewById(R.id.buyItemButton);
        confirmpurchasequestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popup_buy_item_fragment exercise = new popup_buy_item_fragment();
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragplaceholder, exercise); // Using .replace() is often safer.
                ft.addToBackStack(null); // Allows user to close fragment with the back button.
                ft.commit();
            }
        });


        ImageButton gobackpage = findViewById(R.id.back);
        gobackpage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(BuyItem.this, Shop.class);
                startActivity(intent);
            }
        });
    }
}
