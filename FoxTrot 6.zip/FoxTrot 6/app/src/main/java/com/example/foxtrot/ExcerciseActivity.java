package com.example.foxtrot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ExcerciseActivity extends AppCompatActivity {

    private static final int ADD_EXERCISE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.main_activity_scrollview);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button exercise1Button = findViewById(R.id.exercise_1);
        exercise1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ExcerciseActivity.this, StartWorkoutActivity.class);
                intent.putExtra("TIMER_DURATION", 15 * 60 * 1000L);
                startActivity(intent);
            }
        });

        Button exercise2Button = findViewById(R.id.exercise_2);
        exercise2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ExcerciseActivity.this, StartWorkoutActivity.class);
                intent.putExtra("TIMER_DURATION", 30 * 60 * 1000L);
                startActivity(intent);
            }
        });

        ImageButton addNewExerciseButton = findViewById(R.id.add_exercise);
        addNewExerciseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ExcerciseActivity.this, AddExerciseActivity.class);
                startActivityForResult(intent, ADD_EXERCISE_REQUEST);
            }
        });

        ImageView getDataButton = findViewById(R.id.getdata);
        getDataButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ExcerciseActivity.this, StartWorkoutActivity.class);
                intent.putExtra("TIMER_DURATION", 10 * 60 * 1000L); // 10 minutes default
                startActivity(intent);
            }
        });

        ImageButton sendToShop = findViewById(R.id.sendtoshop);
        sendToShop.setOnClickListener(v -> {
            Intent intent = new Intent(ExcerciseActivity.this, Shop.class);
            startActivity(intent);
        });

        ImageButton sendToWorkout = findViewById(R.id.sendtoworkout);
        sendToWorkout.setOnClickListener(v -> {
            Intent intent = new Intent(ExcerciseActivity.this, ExcerciseActivity.class);
            startActivity(intent);
        });

        ImageButton sendToSettings = findViewById(R.id.sendtosetting);
        sendToSettings.setOnClickListener(v -> {
            Intent intent = new Intent(ExcerciseActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        ImageButton sendToMainPage = findViewById(R.id.sendtomainpage);
        sendToMainPage.setOnClickListener(v -> {
            Intent intent = new Intent(ExcerciseActivity.this, Screentwo.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_EXERCISE_REQUEST && resultCode == RESULT_OK) {
            String exerciseName = data.getStringExtra("exercise_name");
            long exerciseTime = data.getIntExtra("exercise_time", 0) * 60 * 1000L;

            LinearLayout layout = findViewById(R.id.exercises_linear_layout);
            Button newExerciseButton = new Button(this);
            newExerciseButton.setText(exerciseName);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, 
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 16);
            newExerciseButton.setLayoutParams(params);
            newExerciseButton.setOnClickListener(v -> {
                Intent intent = new Intent(ExcerciseActivity.this, StartWorkoutActivity.class);
                intent.putExtra("TIMER_DURATION", exerciseTime);
                startActivity(intent);
            });
            layout.addView(newExerciseButton);
        }
    }
}
