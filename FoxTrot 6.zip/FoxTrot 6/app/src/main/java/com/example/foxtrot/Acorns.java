package com.example.foxtrot; // Replace with your package name

import android.app.Application;

public class Acorns extends Application {
//this was all Zach
    private int myGlobalAcorns;

    @Override
    public void onCreate() {
        super.onCreate();
        // Initialize your global variables here that only does it once!
        myGlobalAcorns = 0;
    }
    // Getter methods to access your global variables

    public int getAcorns() {
        return myGlobalAcorns;
    }

    public void addtotheAcorns(int myGlobalInt) {
        this.myGlobalAcorns += myGlobalInt;
    }
}